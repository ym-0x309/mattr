"""Phase 0 smoke test — runs inside Blender.

Usage:
    blender -b -P blender_mattr_exporter/tests/test_phase0.py

This script registers the addon classes from the source directory,
invokes the export operator with a temp path, and verifies that the operator
returns {'FINISHED'}.

If the same addon is already installed/enabled in Blender's user preferences,
it is temporarily disabled to avoid class registration conflicts.
"""

import sys
from pathlib import Path

# 개별 실행 시 프로젝트 루트를 sys.path에 추가한다.
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import bpy

from blender_mattr_exporter.tests import common


def main():
    common.reset_addon()

    tmpdir = common.tempdir()
    try:
        test_path = tmpdir / "test.mattr.json"
        result = bpy.ops.export_mesh.mattr(filepath=str(test_path))
        assert result == {"FINISHED"}, f"Operator returned {result}"
        print(f"Phase 0 smoke test passed: {test_path}")
    finally:
        import shutil

        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
